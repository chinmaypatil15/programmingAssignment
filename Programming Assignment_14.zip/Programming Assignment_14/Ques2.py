#Write a program to compute the frequency of the words from the input. The output should output after sorting the key alphanumerically.
#Suppose the following input is supplied to the program:
#New to Python or choosing between Python 2 and Python 3? Read Python 2 or Python 3.
#Then, the output should be:
#2:2
#3.:1
#3?:1
#New:1
#Python:5
#Read:1
#and:1
#between:1
#choosing:1
#or:2
#to:1

def word_frequency(sentence):
    words = sentence.split()
    frequency = {}
    for word in words:
        frequency[word] = frequency.get(word, 0) + 1
    return frequency

def sort_alphanumeric(frequency):
    return sorted(frequency.items(), key=lambda x: x[0])

sentence = "Full-stack data science course is a live mentor-led job guaranteed certification program with a full-time one-year internship provided by iNeuron"
frequency = word_frequency(sentence)
sorted_frequency = sort_alphanumeric(frequency)

for word, count in sorted_frequency:
    print(f"{word}:{count}")
