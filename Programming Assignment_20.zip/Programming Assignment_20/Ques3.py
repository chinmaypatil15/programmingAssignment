#Create a function that takes the height and radius of a cone as arguments and returns the volume of the cone rounded to the nearest hundredth.See the resources tab for the formula.
#Examples
#cone_volume(3, 2) ➞ 12.57
#cone_volume(15, 6) ➞ 565.49
#cone_volume(18, 0) ➞ 0


import math

def cone_volume(height, radius):
    volume = (math.pi * radius**2 * height) / 3
    return round(volume, 2)
radius = float(5)
height = float(12)
print("Volume Of Cone : ", cone_volume(radius, height))
print(cone_volume(3, 2))
print(cone_volume(15, 6))
print(cone_volume(18, 0))