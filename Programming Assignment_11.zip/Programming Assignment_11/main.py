#1.	Write a Python program to find words which are greater than given length k?
def string_k(k, str):
    string = []
    text = str.split(" ")
    for x in text:
        if len(x) > k:
            string.append(x)
    return string
k = 3
str = "krunali went for kokan in kadambari express"
print(string_k(k, str))

#2.	Write a Python program for removing i-th character from a string?
def remove_ith_char(string, i):
    return string[:i] + string[i+1:]
string = "This is a krunalis dairy"
i = 12
print(remove_ith_char(string, i))


#3.	Write a Python program to split and join a string?
def split_string(string):
    list_string = string.split(' ')
    return list_string
def join_string(list_string):
    string = '-'.join(list_string)
    return string
if __name__ == '__main__':
    string = 'Krunu eat apple'
    list_string = split_string(string)
    print(list_string)
    new_string = join_string(list_string)
    print(new_string)

#4.	Write a Python to check if a given string is binary string or not?
def check(string):
	p = set(string)

	s = {'0', '1'}
	if s == p or p == {'0'} or p == {'1'}:
		print("Yes")
	else:
		print("No")
if __name__ == "__main__":
	string = "101010000111"
	check(string)

#5.	Write a Python program to find uncommon words from two Strings?

def UncommonWords(A, B):
	count = {}
	for word in A.split():
		count[word] = count.get(word, 0) + 1
	for word in B.split():
		count[word] = count.get(word, 0) + 1
	return [word for word in count if count[word] == 1]

A = "Geeks for Geeks"
B = "Learning from iNeuron"
print(UncommonWords(A, B))


#6.	Write a Python to find all duplicate characters in string?
from collections import Counter
def find_dup_char(input):
    WC = Counter(input)
    for letter, count in WC.items():
        if (count > 1):
            print(letter)
if __name__ == "__main__":
    input = 'naama raama kamali'
    find_dup_char(input)

#7.	Write a Python Program to check if a string contains any special character?
def contains_special_char(string):
    special_chars = r"!@#$%^&*()_+-=[]{}|;':\"<>,.?/\\"
    for char in string:
        if char in special_chars:
            return True
    return False

string = "sample string"
print(contains_special_char(string))


