#1.	Write a Python Program to Find the Factorial of a Number?
def factorial(n):
    if n == 0:
        return 1
    else:
        return n * factorial(n-1)

num = int(input("Enter a number: "))

if num < 0:
    print("Sorry, factorial does not exist for negative numbers")
elif num == 0:
    print("The factorial of 0 is 1")
else:
    print("The factorial of", num, "is", factorial(num))


#2.	Write a Python Program to Display the multiplication Table?
num = int(input("Enter a number to display its multiplication table: "))

for i in range(1, 11):
    print(num, "x", i, "=", num * i)


#3.	Write a Python Program to Print the Fibonacci sequence?
def fibonacci(n):
    if n<0:
        print("Incorrect input")
    elif n<=1:
        return n
    else:
        return fibonacci(n-1)+fibonacci(n-2)

nterms = int(input("How many terms? "))

if nterms<=0:
    print("Plese enter a positive integer")
else:
    print("Fibonacci sequence:")
    for i in range(nterms):
        print(fibonacci(i))


#4.	Write a Python Program to Check Armstrong Number?
num = int(input("Enter a number: "))

sum = 0
temp = num
while temp > 0:
    digit = temp % 10
    sum += digit ** 3
    temp //= 10

if num == sum:
    print(num, "is an Armstrong number")
else:
    print(num, "is not an Armstrong number")


#5.	Write a Python Program to Find Armstrong Number in an Interval?
start = int(input("Enter the start of the interval: "))
end = int(input("Enter the end of the interval: "))

for num in range(start, end + 1):
    sum = 0
    temp = num
    while temp > 0:
        digit = temp % 10
        sum += digit ** 3
        temp //= 10

    if num == sum:
        print(num)


#6.	Write a Python Program to Find the Sum of Natural Numbers?
num = int(input("Enter a positive integer: "))

if num < 0:
    print("Enter a positive integer")
else:
    sum = 0
    while num > 0:
        sum += num
        num -= 1
    print("The sum of natural numbers is", sum)


