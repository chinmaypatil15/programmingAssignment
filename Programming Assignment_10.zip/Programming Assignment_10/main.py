#1.	Write a Python program to find sum of elements in list?
def list_sum(lst):
    return sum(lst)

lst = [1, 2, 3, 4, 5]
result = list_sum(lst)
print("Sum of elements in list:", result)

#2.	Write a Python program to  Multiply all numbers in the list?
def multiply_list(lst):
    product = 1
    for num in lst:
        product *= num
    return product

lst = [1, 2, 3, 4, 5]
result = multiply_list(lst)
print("Product of elements in list:", result)


#3.	Write a Python program to find smallest number in a list?
def find_smallest(lst):
    return min(lst)

lst = [1, 2, 3, 4, 5]
result = find_smallest(lst)
print("Smallest number in list:", result)


#4.	Write a Python program to find largest number in a list?
def find_largest(lst):
    return max(lst)

lst = [1, 2, 3, 4, 5]
result = find_largest(lst)
print("Largest number in list:", result)


#5.	Write a Python program to find second largest number in a list?
def find_second_largest(lst):
    lst = sorted(set(lst), reverse=True)
    return lst[1]

lst = [1, 2, 3, 4, 5, 5]
result = find_second_largest(lst)
print("Second largest number in list:", result)


#6.	Write a Python program to find N largest elements from a list?
def find_n_largest(lst, n):
    lst = sorted(lst, reverse=True)
    return lst[:n]

lst = [1, 2, 3, 4, 5, 5]
n = 3
result = find_n_largest(lst, n)
print("{} largest elements in list: {}".format(n, result))


#7.	Write a Python program to print even numbers in a list?
def print_even(lst):
    for num in lst:
        if num % 2 == 0:
            print(num)

lst = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
print_even(lst)


#8.	Write a Python program to print odd numbers in a List?
def print_odd(lst):
    for num in lst:
        if num % 2 != 0:
            print(num)

lst = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
print_odd(lst)


#9.	Write a Python program to Remove empty List from List?
def remove_empty(lst):
    return [x for x in lst if x]

lst = [[1, 2, 3], [], [4, 5], [], [6]]
result = remove_empty(lst)
print("List without empty lists:", result)


#10. Write a Python program to Cloning or Copying a list?
def clone_list(lst):
    return lst[:]

lst = [1, 2, 3, 4, 5]
result = clone_list(lst)
print("Cloned list:", result)


#11. Write a Python program to Count occurrences of an element in a list?
def count_occurrences(lst, elem):
    return lst.count(elem)

lst = [1, 2, 3, 4, 5, 1, 1, 2, 2, 2]
elem = 2
result = count_occurrences(lst, elem)
print("Number of occurrences of {} in list: {}".format(elem, result))


