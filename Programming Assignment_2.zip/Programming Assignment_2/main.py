#1.	Write a Python program to convert kilometers to miles?
def km_to_miles(kilometers):
    miles = kilometers * 0.621371
    return miles

kilometers = float(input("Enter distance in kilometers: "))
miles = km_to_miles(kilometers)
print("Distance in miles: ", miles)


#2.	Write a Python program to convert Celsius to Fahrenheit?
def celsius_to_fahrenheit(celsius):
    fahrenheit = (celsius * 9/5) + 32
    return fahrenheit

celsius = float(input("Enter temperature in Celsius: "))
fahrenheit = celsius_to_fahrenheit(celsius)
print("Temperature in Fahrenheit: ", fahrenheit)


#3.	Write a Python program to display calendar?

import calendar

year = int(input("Enter year: "))
month = int(input("Enter month: "))

print(calendar.month(year, month))

#4.	Write a Python program to solve quadratic equation?
import math

print("Quadratic function : (a * x^2) + b*x + c")
a = float(input("a: "))
b = float(input("b: "))
c = float(input("c: "))

r = b**2 - 4*a*c

if r > 0:
    num_roots = 2
    x1 = (((-b) + math.sqrt(r))/(2*a))
    x2 = (((-b) - math.sqrt(r))/(2*a))
    print("There are 2 roots: %f and %f" % (x1, x2))
elif r == 0:
    num_roots = 1
    x = (-b) / 2*a
    print("There is one root: ", x)
else:
    num_roots = 0
    print("No roots, discriminant < 0.")

equation = (a*x1*x1) + (b*x1) + c
print("Checking root 1... x = %f" % x1)
print("f(x) = %f" % equation)

equation = (a*x2*x2) + (b*x2) + c
print("Checking root 2... x = %f" % x2)
print("f(x) = %f" % equation)



#5.	Write a Python program to swap two variables without temp variable?

c = int(input("Enter value of c: "))
d = int(input("Enter value of d: "))

c = c + d
d = c - d
c = c - d

print("After swapping: c =", c, " d =", d)

