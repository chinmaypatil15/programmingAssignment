#1.	Write a Python Program to Display Fibonacci Sequence Using Recursion?
def fibonacci(n):
   if n<= 0:
      return 0
   elif n == 1:
      return 1
   else:
      return fibonacci(n-1) + fibonacci(n-2)

n = 9
print("Fibonacci sequence:")
for i in range(n):
   print(fibonacci(i))


#2.	Write a Python Program to Find Factorial of Number Using Recursion?
def factorial(n):
   if n == 1:
      return 1
   else:
      return n * factorial(n-1)

num = 8
print("The factorial of", num, "is", factorial(num))


#3.	Write a Python Program to calculate your Body Mass Index?
height = float(input("Enter height in meters: "))
weight = float(input("Enter weight in kilograms: "))

bmi = weight / (height ** 2)
print("Your BMI is:", bmi)


#4.	Write a Python Program to calculate the natural logarithm of any number?
import math

num = float(input("Enter a number: "))
result = math.log(num)
print("The natural logarithm of", num, "is", result)


#5.	Write a Python Program for cube sum of first n natural numbers?
def sumOfCubes(n):
   if n == 1:
      return 1
   else:
      return n**3 + sumOfCubes(n-1)

num = float(input("Enter nummber: "))
print("The sum of cubes of first", num, "natural numbers is", sumOfCubes(num))


