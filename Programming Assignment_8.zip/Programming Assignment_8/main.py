#1.	Write a Python Program to Add Two Matrices?
def add_matrices(mat1, mat2):
    rows = len(mat1)
    cols = len(mat1[0])
    result = [[0 for j in range(cols)] for i in range(rows)]
    for i in range(rows):
        for j in range(cols):
            result[i][j] = mat1[i][j] + mat2[i][j]
    return result

mat1 = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
mat2 = [[9, 8, 7], [6, 5, 4], [3, 2, 1]]
print("Sum of matrices:", add_matrices(mat1, mat2))


#2.	Write a Python Program to Multiply Two Matrices?
def multiply_matrices(mat1, mat2):
    rows1 = len(mat1)
    cols1 = len(mat1[0])
    rows2 = len(mat2)
    cols2 = len(mat2[0])
    if cols1 != rows2:
        return "Cannot multiply matrices with given dimensions"
    result = [[0 for j in range(cols2)] for i in range(rows1)]
    for i in range(rows1):
        for j in range(cols2):
            for k in range(cols1):
                result[i][j] += mat1[i][k] * mat2[k][j]
    return result

mat1 = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
mat2 = [[9, 8, 7], [6, 5, 4], [3, 2, 1]]
print("Product of matrices:", multiply_matrices(mat1, mat2))


#3.	Write a Python Program to Transpose a Matrix?
def transpose_matrix(mat):
    rows = len(mat)
    cols = len(mat[0])
    result = [[0 for j in range(rows)] for i in range(cols)]
    for i in range(rows):
        for j in range(cols):
            result[j][i] = mat[i][j]
    return result

mat = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
print("Transpose of matrix:", transpose_matrix(mat))


#4.	Write a Python Program to Sort Words in Alphabetic Order?
def sort_words(sentence):
    words = sentence.split()
    words.sort()
    return " ".join(words)

sentence = "this is a sample sentence"
print("Words sorted in alphabetic order:", sort_words(sentence))


#5.	Write a Python Program to Remove Punctuation From a String?
import string

def remove_punctuation(sentence):
    return sentence.translate(str.maketrans("", "", string.punctuation))

sentence = "This is a sample sentence, with punctuation!"


