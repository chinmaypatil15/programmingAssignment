#Using list comprehensions, create a function that finds all even numbers from 1 to the given number.
#Examples
#find_even_nums(8) ➞ [2, 4, 6, 8]
#find_even_nums(4) ➞ [2, 4]
#find_even_nums(2) ➞ [2]


[2, 4, 6, 8, 10]
def find_even_nums(n):
    even =[x for x in range(2,n+1) if x % 2 == 0]
    return even
n = int(input('Enter a number : '))
print(find_even_nums(n))
print(find_even_nums(8))