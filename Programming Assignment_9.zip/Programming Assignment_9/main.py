#1.	Write a Python program to check if the given number is a Disarium Number?
def is_disarium(n):
    num = n
    sum = 0
    length = len(str(n))
    while num > 0:
        digit = num % 10
        sum += digit ** (length)
        length -= 1
        num //= 10
    return sum == n

n = int(input("Enter a number: "))
print(is_disarium(n))


#2.	Write a Python program to print all disarium numbers between 1 to 100?
def is_disarium(n):
    num = n
    sum = 0
    length = len(str(n))
    while num > 0:
        digit = num % 10
        sum += digit ** (length)
        length -= 1
        num //= 10
    return sum == n

print("Disarium numbers between 1 and 100:")
for i in range(1, 101):
    if is_disarium(i):
        print(i, end=", ")


#3.	Write a Python program to check if the given number is Happy Number?
def is_happy(n):
    seen = set()
    while n != 1 and n not in seen:
        seen.add(n)
        n = sum(int(i) ** 2 for i in str(n))
    return n == 1

n = int(input("Enter a number: "))
print(is_happy(n))


#4.	Write a Python program to print all happy numbers between 1 and 100?
def is_happy(n):
    seen = set()
    while n != 1 and n not in seen:
        seen.add(n)
        n = sum(int(i) ** 2 for i in str(n))
    return n == 1

print("Happy numbers between 1 and 100:")
for i in range(1, 101):
    if is_happy(i):
        print(i, end=", ")


#5.	Write a Python program to determine whether the given number is a Harshad Number?
def is_harshad(n):
    return n % sum(int(i) for i in str(n)) == 0

n = int(input("Enter a number: "))
print(is_harshad(n))


#6.	Write a Python program to print all pronic numbers between 1 and 100?
def is_pronic(n):
    i = 1
    while i * (i + 1) < n:
        i += 1
    return i * (i + 1) == n

print("Pronic numbers between 1 and 100:")
for i in range(1, 101):
    if is_pronic(i):
        print(i, end=", ")
