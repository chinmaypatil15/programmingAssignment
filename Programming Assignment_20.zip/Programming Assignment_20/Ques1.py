#Create a function that takes a list of strings and integers, and filters out the list so that it
#returns a list of integers only.
#Examples
#filter_list([1, 2, 3, 'a', 'b', 4]) ➞ [1, 2, 3, 4]
#filter_list(['A', 0, 'Edabit', 1729, 'Python', '1729']) ➞ [0, 1729]
#filter_list(['Nothing', 'here']) ➞ []

lst = [1, 2, 3, 'a', 'b', 4]
def filter_list(lst):
    return [x for x in lst if type(x) == int]
print(filter_list([1, 2, 3, 'a', 'b', 4]))
print(filter_list(['A', 0, 'Edabit', 1729, 'Python', '1729']))
print(filter_list(['Nothing', 'here']))