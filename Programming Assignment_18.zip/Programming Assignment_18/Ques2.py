#The "Reverser" takes a string as input and returns that string in reverse order, with the opposite case.
#Examples
#reverse("Hello World") ➞ "DLROw OLLEh"
#reverse("ReVeRsE") ➞ "eSrEvEr"
#reverse("Radar") ➞ "RADAr"


def reverse(str):
    str = str[::-1]
    return str.swapcase()
print(reverse('ReVeRsE'))