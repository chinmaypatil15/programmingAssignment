#Create a function that replaces all the vowels in a string with a specified character.
#Examples
#replace_vowels("the aardvark", "#") ➞ "th# ##rdv#rk"
#replace_vowels("minnie mouse", "?") ➞ "m?nn?? m??s?"
#replace_vowels("shakespeare", "*") ➞ "sh*k*sp**r*"


def replace_vowels(s, ch):
    vowels = "aeiouAEIOU"
    result = ""
    for char in s:
        if char in vowels:
            result += ch
        else:
            result += char
    return result

input_str = input("enter a string : ")
s = input("enter a vowel replacing string : ")
print("\nGiven Sting:", input_str)
print("Given Specified Character:", s)
print("Afer replacing vowels with the specified character:",replace_vowels(input_str, s))