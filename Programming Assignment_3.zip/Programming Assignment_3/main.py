#1.	Write a Python Program to Check if a Number is Positive, Negative or Zero?
number = float(input("Enter a number: "))
if number > 0:
   print("Positive number")
elif number == 0:
   print("Zero")
else:
   print("Negative number")

#2.	Write a Python Program to Check if a Number is Odd or Even?
num = int(input("Enter an integer: "))
if num % 2 == 0:
   print("Even")
else:
   print("Odd")

#3.	Write a Python Program to Check Leap Year?
year = int(input("Enter a year: "))
if year % 4 == 0:
   if year % 100 == 0:
      if year % 400 == 0:
         print("Leap Year")
      else:
         print("Not a Leap Year")
   else:
      print("Leap Year")
else:
   print("Not a Leap Year")


#4.	Write a Python Program to Check Prime Number?
num = int(input("Enter a number: "))
if num > 1:
   for i in range(2, num):
      if (num % i) == 0:
         print(num, "is not a prime number")
         break
   else:
      print(num, "is a prime number")
else:
   print(num, "is not a prime number")


#5.	Write a Python Program to Print all Prime Numbers in an Interval of 1-10000?
lower = 1
upper = 10000
print("Prime numbers between", lower, "and", upper, "are:")
for num in range(lower, upper + 1):
   if num > 1:
      for i in range(2, num):
         if (num % i) == 0:
            break
      else:
         print(num)

