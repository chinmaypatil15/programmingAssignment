#Create a function that takes a number as an argument and returns True or False depending on whether the number is symmetrical or not. A number is symmetrical when it is the same as its reverse.
#Examples
#is_symmetrical(7227) ➞ True
#is_symmetrical(12567) ➞ False
#is_symmetrical(44444444) ➞ True
#is_symmetrical(9939) ➞ False
#is_symmetrical(1112111) ➞ True


def is_symmetrical(num):
    currentDigit = reversedDigit = 0
    remainingNum = num
    while(remainingNum != 0):

        currentDigit = remainingNum % 10

        reversedDigit = reversedDigit * 10 + currentDigit
        print('Reveresed Digit :',reversedDigit)
        remainingNum = remainingNum // 10

    if reversedDigit == num:
        print('Num {} is symmetrical'.format(num))
    else:
        print('Num {} is not symmetrical'.format(num))

print(is_symmetrical(7227))
print(is_symmetrical(12567))
print(is_symmetrical(44444444))
print(is_symmetrical(9939))
print(is_symmetrical(1112111))