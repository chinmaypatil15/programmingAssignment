#1.	Write a Python program to print "Hello Python"?
print("Hello Python")
#2.	Write a Python program to do arithmetical operations addition and division.?

#Addition
a = 5
b = 3
c = a + b
print("The sum of", a, "and", b, "is", c)
#Division
d = a / b
print("The result of division of", a, "by", b, "is", d)

#3.	Write a Python program to find the area of a triangle?

def triangle_area(base, height):
  return (base * height) / 2

base = float(input("Enter the base of the triangle: "))
height = float(input("Enter the height of the triangle: "))

area = triangle_area(base, height)
print("The area of the triangle is", area)

#4.	Write a Python program to swap two variables?
def swap(a, b):
  temp = a
  a = b
  b = temp
  return a, b

x = int(input("Enter value for x: "))
y = int(input("Enter value for y: "))

x, y = swap(x, y)

print("The value of x after swapping:", x)
print("The value of y after swapping:", y)

#5.	Write a Python program to generate a random number?

import random

random_number = random.randint(1, 100)

print("Random number between 1 and 100:", random_number)
